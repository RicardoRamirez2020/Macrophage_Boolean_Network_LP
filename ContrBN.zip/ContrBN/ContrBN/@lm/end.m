function ind = end(obj,k,n)
% LM/END    overloaded end for lm class

% $Id: end.m 10 2010-12-25 15:04:44Z hsqi $

l = length(obj);
ind = l(k);