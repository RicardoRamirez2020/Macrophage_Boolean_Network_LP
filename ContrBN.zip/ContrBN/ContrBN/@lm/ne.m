function result = ne(a,b)
% LM/NE    overloaded ne for lm class

% $Id: ne.m 13 2010-12-27 14:29:56Z hsqi $

result = ~eq(a,b);