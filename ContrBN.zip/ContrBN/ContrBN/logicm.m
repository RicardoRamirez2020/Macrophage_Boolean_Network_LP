function m = logicm(varargin)
% LOGICM    Alias function for LM class constructor, compatible for old versions.

% $Id: logicm.m 16 2013-01-14 16:55:23Z hsqi $

m = lm(varargin{:});