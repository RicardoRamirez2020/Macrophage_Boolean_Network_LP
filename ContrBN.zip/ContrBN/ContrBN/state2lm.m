function v = state2lm(varargin)
% STATE2LM    Alias of m-function S2V, compatible for older versions

% $Id: state2lm.m 9 2010-12-22 14:32:11Z hsqi $

v = s2v(varargin{:});