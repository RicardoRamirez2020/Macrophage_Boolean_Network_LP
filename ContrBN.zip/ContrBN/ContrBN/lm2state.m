function s = lm2state(varargin)
% LM2STATE    Alias of m-function V2S, compatible for older versions

% $Id: lm2state.m 9 2010-12-22 14:32:11Z hsqi $

s = v2s(varargin{:});