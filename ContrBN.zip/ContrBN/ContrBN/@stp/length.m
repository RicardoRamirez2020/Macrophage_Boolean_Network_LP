function r = length (m)
% STP/LENGTH    overloaded length for stp class

% $Id: length.m 7 2010-04-09 12:11:31Z hsqi $

r = max(size(m));