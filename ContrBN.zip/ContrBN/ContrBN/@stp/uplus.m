function X = uplus(M)
% STP/UPLUS    overloaded uplus for stp class

% $Id: uplus.m 7 2010-04-09 12:11:31Z hsqi $

X = M; 