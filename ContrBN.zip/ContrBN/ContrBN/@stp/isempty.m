function r = isempty (m)
% STP/ISEMPTY    overloaded isempty method for stp class

% $Id: isempty.m 7 2010-04-09 12:11:31Z hsqi $

r = isempty(m.c);