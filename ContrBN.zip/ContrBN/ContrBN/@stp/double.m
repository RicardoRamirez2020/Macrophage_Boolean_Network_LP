function B = double(A)
% STP/DOUBLE    double converter for stp class

% $Id: double.m 7 2010-04-09 12:11:31Z hsqi $

B = A.c;